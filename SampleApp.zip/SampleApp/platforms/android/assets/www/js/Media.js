var PlayMedia = function() {

	this.launchMedia = function() {
		var media = new Media('cdvfile://' + cordova.file.externalRootDirectory + '/Kyoe-sar-ma-ya.mp3');
		alert(media);
		media.play();
		// window.Media.play(options);
	}
}