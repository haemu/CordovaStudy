var DataService = function() {

	this.initialize = function() {
		var deferred = $.Deferred();
		deferred.resolve();
		return  deferred.promise();
	}

	this.getData = function() {
		var deferred = $.Deferred();
		var results = words;

		deferred.resolve(results);
		return deferred.promise();
	}

	var words = [
		{"kanji": "勉強", "pronunciation": "べん きょう", "meaning": "study"},
		{"kanji": "練習", "pronunciation": "れん しゅう", "meaning": "practice"}
	];
}